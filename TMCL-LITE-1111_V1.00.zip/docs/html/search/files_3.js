var searchData=
[
  ['globals_2ec',['Globals.c',['../_globals_8c.html',1,'']]],
  ['globals_2eh',['Globals.h',['../_globals_8h.html',1,'']]]
];
