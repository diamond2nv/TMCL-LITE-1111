var searchData=
[
  ['readbackdatagram',['ReadBackDatagram',['../_t_m_c262_8c.html#a1d5c9122f430c46fc263674198521297',1,'TMC262.c']]],
  ['relativepositioningoptioncode',['RelativePositioningOptionCode',['../_commands_8c.html#a5b8302a5a082127ef49318e9693f1d0a',1,'Commands.c']]],
  ['resetrequested',['ResetRequested',['../_commands_8c.html#ac72ea3d852e56cfa2fb557d036652a84',1,'Commands.c']]]
];
