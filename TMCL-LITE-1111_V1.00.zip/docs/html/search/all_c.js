var searchData=
[
  ['opcode',['Opcode',['../struct_t_t_m_c_l_command.html#ab5ab5cd7264614d96f6d280f4871bc22',1,'TTMCLCommand::Opcode()'],['../struct_t_t_m_c_l_reply.html#ab5ab5cd7264614d96f6d280f4871bc22',1,'TTMCLReply::Opcode()']]]
];
