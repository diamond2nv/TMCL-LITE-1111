var searchData=
[
  ['read262state',['Read262State',['../_t_m_c262_8c.html#afc6b1d15a6b3ec92660b4081d8b5d469',1,'Read262State(UCHAR Which262, UCHAR *Phases, UCHAR *MStep, UINT *StallGuard, UCHAR *SmartEnergy, UCHAR *Flags):&#160;TMC262.c'],['../_t_m_c262_8h.html#a95490bfd4e3b32b8615bf6a1c3a23892',1,'Read262State(UCHAR Which262, UCHAR *Phases, UCHAR *MStep, UINT *StallGuard, UCHAR *SmartEnergy, UCHAR *Flags):&#160;TMC262.c']]],
  ['readandcleartmc43xxevents',['ReadAndClearTMC43xxEvents',['../_t_m_c4361_8c.html#a8b9bb5aafbbbd04f6f6eb00202cce29c',1,'ReadAndClearTMC43xxEvents(UCHAR Axis, UINT EventMask):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#af5bb87307bae8b743cf8f62a10967e4f',1,'ReadAndClearTMC43xxEvents(UCHAR Axis, UINT EventMask):&#160;TMC4361.c']]],
  ['readeepromblock',['ReadEepromBlock',['../_eeprom_8c.html#a18bea515208ade65a25a32257b4038ec',1,'ReadEepromBlock(UINT Address, UCHAR *Block, UINT Size):&#160;Eeprom.c'],['../_eeprom_8h.html#a4e34031ac06e1c0e083d9ee9d57cafc2',1,'ReadEepromBlock(UINT Address, UCHAR *Block, UINT Size):&#160;Eeprom.c']]],
  ['readeeprombyte',['ReadEepromByte',['../_eeprom_8c.html#a360f69da5c23e00b21cb8dffaa9a3b1f',1,'ReadEepromByte(UINT Address):&#160;Eeprom.c'],['../_eeprom_8h.html#a3e96929c04c6e62f6641b673eb4788cd',1,'ReadEepromByte(UINT Address):&#160;Eeprom.c']]],
  ['readrs485',['ReadRS485',['../_r_s485_8c.html#af029121f9da0968e1608928504bc2755',1,'RS485.c']]],
  ['readtmc43xxint',['ReadTMC43xxInt',['../_t_m_c4361_8c.html#a337827db354f18fa5750694cd643c17d',1,'ReadTMC43xxInt(UCHAR Axis, UCHAR Address):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#a766ff5d2cffaa45e82b1413d7c875d13',1,'ReadTMC43xxInt(UCHAR Axis, UCHAR Address):&#160;TMC4361.c']]],
  ['readwrite262',['ReadWrite262',['../_t_m_c262_8c.html#a68abfd58f683b8e948d6e101f1372497',1,'TMC262.c']]],
  ['resetcpu',['ResetCPU',['../_i_o_8c.html#ace916e2e6c33a05140b5e7d9f872af96',1,'ResetCPU(UCHAR ResetPeripherals):&#160;IO.c'],['../_i_o_8h.html#ae13de68a65a8eb09d1040d858b4f16fa',1,'ResetCPU(UCHAR ResetPeripherals):&#160;IO.c']]],
  ['resettmc43xx',['ResetTMC43xx',['../_t_m_c4361_8c.html#abc0483bd12f40fd634b1c6e651175c46',1,'ResetTMC43xx(void):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#a14d9076e57c56274784a4ba509ad4bd7',1,'ResetTMC43xx(void):&#160;TMC4361.c']]],
  ['rotateleft',['RotateLeft',['../_commands_8c.html#a8c930c2e3ebddb36da3bf76ec21d28b3',1,'Commands.c']]],
  ['rotateright',['RotateRight',['../_commands_8c.html#a441063121a6474e1ccb53596241591f0',1,'Commands.c']]]
];
