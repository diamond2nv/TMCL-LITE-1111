var searchData=
[
  ['tmc43xxclearbits',['TMC43xxClearBits',['../_t_m_c4361_8c.html#a082672ada0b94d3340b70c132100a151',1,'TMC43xxClearBits(UCHAR Axis, UCHAR Address, UINT BitMask):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#a2b4a95638ffd1c60eb5fddb249a4dd39',1,'TMC43xxClearBits(UCHAR Axis, UCHAR Address, UINT BitMask):&#160;TMC4361.c']]],
  ['tmc43xxsetbits',['TMC43xxSetBits',['../_t_m_c4361_8c.html#a805a1a5e1b1e51628ca93bd60d95ab49',1,'TMC43xxSetBits(UCHAR Axis, UCHAR Address, UINT BitMask):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#af18018e31b71876920eeef6b12720ee2',1,'TMC43xxSetBits(UCHAR Axis, UCHAR Address, UINT BitMask):&#160;TMC4361.c']]],
  ['tmc43xxwritebits',['TMC43xxWriteBits',['../_t_m_c4361_8c.html#a1cfc8b279b4d1d7cddc4ed0e64e39c82',1,'TMC43xxWriteBits(UCHAR Axis, UCHAR Address, UINT Value, UCHAR Start, UCHAR Size):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#a6def38dd3bcb4813963a11f23ebcf04f',1,'TMC43xxWriteBits(UCHAR Axis, UCHAR Address, UINT Value, UCHAR Start, UCHAR Size):&#160;TMC4361.c']]]
];
