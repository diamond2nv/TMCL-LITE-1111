var searchData=
[
  ['peektmc43xxevents',['PeekTMC43xxEvents',['../_t_m_c4361_8c.html#a64ee8a36a630687c4d278cab2a98f6c0',1,'PeekTMC43xxEvents(UCHAR Axis):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#a600363735219c89fdd3e834128f04f4a',1,'PeekTMC43xxEvents(UCHAR Axis):&#160;TMC4361.c']]],
  ['processcommand',['ProcessCommand',['../_commands_8c.html#aaf1ad16a40241568160f8e08e6026d72',1,'ProcessCommand(void):&#160;Commands.c'],['../_commands_8h.html#a3ea6d6d2906dc85bef7c2f85c61a8585',1,'ProcessCommand(void):&#160;Commands.c']]]
];
