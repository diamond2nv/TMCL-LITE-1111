var searchData=
[
  ['can_2ec',['Can.c',['../_can_8c.html',1,'']]],
  ['can_2eh',['Can.h',['../_can_8h.html',1,'']]],
  ['canbitrate',['CANBitrate',['../struct_t_module_config.html#a161011c5d83ff8b1ab78705ca8212a6c',1,'TModuleConfig']]],
  ['cangetmessage',['CanGetMessage',['../_can_8c.html#a61b0676273bee10cb773097e2b4e7329',1,'CanGetMessage(TCanFrame *Msg):&#160;Can.c'],['../_can_8h.html#aba28a28000a0ef71d10958c7b26ccdb6',1,'CanGetMessage(TCanFrame *Msg):&#160;Can.c']]],
  ['canreceiveid',['CANReceiveID',['../struct_t_module_config.html#a7f2c4e2240cecfdd22c1177d468dd199',1,'TModuleConfig']]],
  ['cansendid',['CANSendID',['../struct_t_module_config.html#a94fa479eb06d07b946cf74dd21ece594',1,'TModuleConfig']]],
  ['cansendmessage',['CanSendMessage',['../_can_8c.html#a39a6c8c363ad5ef8e374fc058272d953',1,'CanSendMessage(TCanFrame *Msg):&#160;Can.c'],['../_can_8h.html#ae0c5f2ece02b94022e319e7d76efb188',1,'CanSendMessage(TCanFrame *Msg):&#160;Can.c']]],
  ['checkuarttimeout',['CheckUARTTimeout',['../_r_s485_8c.html#ac688406b7cc1fd42a41d1dd1ef77205e',1,'CheckUARTTimeout(void):&#160;RS485.c'],['../_r_s485_8h.html#afdc1941b0d847d2e983602ad213b84da',1,'CheckUARTTimeout(void):&#160;RS485.c']]],
  ['chopperconfig',['ChopperConfig',['../_t_m_c262_8c.html#a1acc6384b919f412bac043778177414e',1,'TMC262.c']]],
  ['closedloopconfig',['ClosedLoopConfig',['../_globals_8c.html#ae10ff37cfc7dff0e7f9f1ecc7e85f74a',1,'ClosedLoopConfig():&#160;Globals.c'],['../_globals_8h.html#ae10ff37cfc7dff0e7f9f1ecc7e85f74a',1,'ClosedLoopConfig():&#160;Globals.c']]],
  ['closedloopinitstate',['ClosedLoopInitState',['../_sys_control_8c.html#a3aae4b059014863b527e56d3dabc2ec4',1,'SysControl.c']]],
  ['closedlooptimer',['ClosedLoopTimer',['../_sys_control_8c.html#a66646a614826e47682a3f90f12effa05',1,'SysControl.c']]],
  ['commands_2ec',['Commands.c',['../_commands_8c.html',1,'']]],
  ['commands_2eh',['Commands.h',['../_commands_8h.html',1,'']]],
  ['convertaccelerationinternaltouser',['ConvertAccelerationInternalToUser',['../_t_m_c4361_8c.html#a124c7557ec721adaf026c0c6d2ce335f',1,'ConvertAccelerationInternalToUser(int InternalAcceleration):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#a6ac01fe12acb808f77978ac7eeb205c5',1,'ConvertAccelerationInternalToUser(int InternalAcceleration):&#160;TMC4361.c']]],
  ['convertaccelerationusertointernal',['ConvertAccelerationUserToInternal',['../_t_m_c4361_8c.html#a6e50f43adf68b0df9581b3ce5432f19f',1,'ConvertAccelerationUserToInternal(int UserAcceleration):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#a30f9c1c5644a8a259957e2eacd7077e5',1,'ConvertAccelerationUserToInternal(int UserAcceleration):&#160;TMC4361.c']]],
  ['convertinternaltointernal',['ConvertInternalToInternal',['../_t_m_c4361_8c.html#aa77e11d0be967b345fa58a91c46c37b3',1,'ConvertInternalToInternal(int Internal):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#a58e59abc063fdd46fb535e21d9d64e3d',1,'ConvertInternalToInternal(int Internal):&#160;TMC4361.c']]],
  ['convertvelocityinternaltouser',['ConvertVelocityInternalToUser',['../_t_m_c4361_8c.html#a2ff2c82188ebb94fe4fa1d6b5dd152e7',1,'ConvertVelocityInternalToUser(int InternalVelocity):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#a45e8961881b55f5ad06af30f6515d389',1,'ConvertVelocityInternalToUser(int InternalVelocity):&#160;TMC4361.c']]],
  ['convertvelocityusertointernal',['ConvertVelocityUserToInternal',['../_t_m_c4361_8c.html#a3abeac34f9c3fc8c9a7a3d395614c85e',1,'ConvertVelocityUserToInternal(int UserVelocity):&#160;TMC4361.c'],['../_t_m_c4361_8h.html#ae0cf731008b070e701f6c2fbf8ab3a0e',1,'ConvertVelocityUserToInternal(int UserVelocity):&#160;TMC4361.c']]],
  ['coolstepconfig',['CoolStepConfig',['../_globals_8c.html#a6dfb7dd95f81ff8a0929efa5eddf90c6',1,'CoolStepConfig():&#160;Globals.c'],['../_globals_8h.html#a6dfb7dd95f81ff8a0929efa5eddf90c6',1,'CoolStepConfig():&#160;Globals.c']]]
];
