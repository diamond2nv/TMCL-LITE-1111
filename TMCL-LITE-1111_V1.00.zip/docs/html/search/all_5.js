var searchData=
[
  ['freewheelingactive',['FreewheelingActive',['../_globals_8c.html#a0801efd735b25b025650340f8a84f297',1,'FreewheelingActive():&#160;Globals.c'],['../_globals_8h.html#a0801efd735b25b025650340f8a84f297',1,'FreewheelingActive():&#160;Globals.c']]]
];
