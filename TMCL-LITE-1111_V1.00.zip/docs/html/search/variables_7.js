var searchData=
[
  ['int32',['Int32',['../struct_t_t_m_c_l_command.html#aefaa7998398897b13e6a4c863df2527e',1,'TTMCLCommand::Int32()'],['../struct_t_t_m_c_l_reply.html#aefaa7998398897b13e6a4c863df2527e',1,'TTMCLReply::Int32()']]]
];
